"""
КОНФИГУРАЦИЯ CODEFORCES AGENT
Все настройки приложения для генерации контестов и перевода задач
"""

import os
import json
import random
import sys
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
from dotenv import load_dotenv

# ==================== ЗАГРУЗКА ПЕРЕМЕННЫХ ОКРУЖЕНИЯ ====================

# Определяем базовую директорию
BASE_DIR = Path(__file__).parent.absolute()
ENV_FILE = BASE_DIR / '.env'

print("=" * 60)
print("🔧 НАСТРОЙКА CODEFORCES AGENT")
print("=" * 60)

# Пытаемся загрузить .env файл
if ENV_FILE.exists():
    try:
        load_dotenv(dotenv_path=ENV_FILE, override=True)
        print(f"✅ .env файл загружен: {ENV_FILE}")
    except Exception as e:
        print(f"⚠️ Ошибка загрузки .env файла: {e}")
        # Пробуем загрузить вручную
        try:
            with open(ENV_FILE, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        os.environ[key.strip()] = value.strip().strip('"\'')
            print(f"✅ .env файл загружен вручную")
        except Exception as e2:
            print(f"❌ Не удалось загрузить .env файл: {e2}")
else:
    print(f"⚠️ .env файл не найден по пути: {ENV_FILE}")
    print("   Создайте файл .env в той же директории")
    print("   Содержимое файла:")
    print("   MISTRAL_API_KEY=ваш_ключ_здесь")

# Пробуем загрузить из текущей директории
load_dotenv()

# Получаем API ключ
MISTRAL_API_KEY = os.environ.get("MISTRAL_API_KEY", "")

# Проверяем и выводим информацию о ключе
if MISTRAL_API_KEY:
    if len(MISTRAL_API_KEY) > 20:
        masked_key = f"{MISTRAL_API_KEY[:8]}...{MISTRAL_API_KEY[-8:]}"
    else:
        masked_key = "***"
    print(f"✅ API ключ найден: {masked_key}")
    print(f"📏 Длина ключа: {len(MISTRAL_API_KEY)} символов")
else:
    print("❌ API ключ не найден в переменных окружения!")
    print("\n📝 КАК ИСПРАВИТЬ:")
    print("1. Создайте файл .env в директории с config.py")
    print("2. Добавьте в него строку: MISTRAL_API_KEY=ваш_ключ")
    print("3. Или установите переменную окружения:")
    print("   Linux/Mac: export MISTRAL_API_KEY=ваш_ключ")
    print("   Windows: set MISTRAL_API_KEY=ваш_ключ")

print("-" * 60)


# ==================== НАСТРОЙКИ API И МОДЕЛЕЙ ====================

class APIConfig:
    """Конфигурация API и моделей"""

    # Mistral API
    MISTRAL_MODEL = "mistral-large-latest"
    MISTRAL_TEMPERATURE = 0.7
    MISTRAL_MAX_TOKENS = 4000

    # Альтернативные модели (если основная недоступна)
    ALTERNATIVE_MODELS = [
        "mistral-medium-latest",
        "mistral-small-latest",
        "open-mistral-7b",
        "open-mixtral-8x7b",
    ]

    # Таймауты и ретраи
    REQUEST_TIMEOUT = 30
    MAX_RETRIES = 3
    RETRY_DELAY = 2

    # Лимиты использования
    MAX_REQUESTS_PER_MINUTE = 10
    MAX_TOKENS_PER_REQUEST = 8000


# ==================== НАСТРОЙКИ ПУТЕЙ И ФАЙЛОВ ====================

class PathConfig:
    """Конфигурация путей и файлов"""

    # Основные файлы
    INPUT_FILE = "input.json"
    OUTPUT_FILE = "output.json"
    PREVIOUS_RESPONSE_FILE = "previous_response.json"
    CONFIG_FILE = "config.py"

    # Директории
    CACHE_DIR = BASE_DIR / "cache"
    LOGS_DIR = BASE_DIR / "logs"
    TEMPLATES_DIR = BASE_DIR / "templates"

    # Файлы кэша
    PROBLEM_CACHE_FILE = CACHE_DIR / "problems_cache.json"
    TRANSLATION_CACHE_FILE = CACHE_DIR / "translations_cache.json"
    CONTEST_CACHE_FILE = CACHE_DIR / "contests_cache.json"

    # Файлы логов
    ERROR_LOG_FILE = LOGS_DIR / "errors.log"
    REQUEST_LOG_FILE = LOGS_DIR / "requests.log"
    AGENT_LOG_FILE = LOGS_DIR / "agent.log"

    # Шаблоны файлов ввода/вывода
    @staticmethod
    def get_input_filename(request_type: str = "contest") -> str:
        """Получить имя входного файла по типу запроса"""
        type_mapping = {
            "contest": "input_contest.json",
            "translation": "input_translation.json",
            "help": "input_help.json",
            "analysis": "input_analysis.json",
            "confirmation": "input_confirmation.json",
        }
        return type_mapping.get(request_type, "input.json")

    @staticmethod
    def get_output_filename(request_type: str = "contest") -> str:
        """Получить имя выходного файла по типу запроса"""
        type_mapping = {
            "contest": "output_contest.json",
            "translation": "output_translation.json",
            "help": "output_help.json",
            "analysis": "output_analysis.json",
            "confirmation": "output_confirmation.json",
        }
        return type_mapping.get(request_type, "output.json")

    @staticmethod
    def setup_directories():
        """Создать необходимые директории"""
        directories = [
            PathConfig.CACHE_DIR,
            PathConfig.LOGS_DIR,
            PathConfig.TEMPLATES_DIR,
        ]

        for directory in directories:
            try:
                directory.mkdir(exist_ok=True, parents=True)
                print(f"📁 Создана директория: {directory}")
            except Exception as e:
                print(f"⚠️ Не удалось создать директорию {directory}: {e}")


# ==================== НАСТРОЙКИ КОНТЕСТОВ ====================

class ContestConfig:
    """Конфигурация генерации контестов"""

    # Количество задач
    MIN_PROBLEMS = 2
    MAX_PROBLEMS = 10
    DEFAULT_PROBLEM_COUNT = 5

    # Уровни сложности (рейтинг Codeforces)
    DIFFICULTY_LEVELS = {
        1: {
            "label": "Новичок",
            "emoji": "🟢",
            "min_rating": 800,
            "max_rating": 1000,
            "description": "Для начинающих, базовые задачи"
        },
        2: {
            "label": "Легкий",
            "emoji": "🟡",
            "min_rating": 1000,
            "max_rating": 1300,
            "description": "Фундаментальные концепции"
        },
        3: {
            "label": "Средний",
            "emoji": "🟠",
            "min_rating": 1300,
            "max_rating": 1600,
            "description": "Типичные задачи Div. 2 A-B"
        },
        4: {
            "label": "Сложный",
            "emoji": "🔴",
            "min_rating": 1600,
            "max_rating": 1900,
            "description": "Задачи Div. 2 C-D, Div. 1 A-B"
        },
        5: {
            "label": "Эксперт",
            "emoji": "💀",
            "min_rating": 1900,
            "max_rating": 2400,
            "description": "Сложные задачи для опытных участников"
        },
        6: {
            "label": "Легендарный",
            "emoji": "👑",
            "min_rating": 2400,
            "max_rating": 3500,
            "description": "Задачи самого высокого уровня"
        }
    }

    # Темы Codeforces
    CF_TOPICS = {
        # Основные темы
        "implementation": {
            "name": "Реализация",
            "emoji": "⚙️",
            "description": "Задачи на аккуратную реализацию идей"
        },
        "math": {
            "name": "Математика",
            "emoji": "🧮",
            "description": "Математические задачи, теория чисел"
        },
        "greedy": {
            "name": "Жадные алгоритмы",
            "emoji": "💰",
            "description": "Задачи, решаемые жадными подходами"
        },
        "dp": {
            "name": "Динамическое программирование",
            "emoji": "📊",
            "description": "Классическое и продвинутое ДП"
        },
        "graphs": {
            "name": "Графы",
            "emoji": "🕸️",
            "description": "Алгоритмы на графах"
        },

        # Дополнительные темы
        "trees": {
            "name": "Деревья",
            "emoji": "🌳",
            "description": "Бинарные деревья, обходы, LCA"
        },
        "strings": {
            "name": "Строки",
            "emoji": "📝",
            "description": "Обработка строк, поиск подстрок"
        },
        "binary search": {
            "name": "Бинарный поиск",
            "emoji": "🎯",
            "description": "Поиск по ответу, тернарный поиск"
        },
        "data structures": {
            "name": "Структуры данных",
            "emoji": "🗃️",
            "description": "Очереди, стеки, множества, хэши"
        },
        "sortings": {
            "name": "Сортировки",
            "emoji": "📊",
            "description": "Алгоритмы сортировки"
        },
        "two pointers": {
            "name": "Два указателя",
            "emoji": "👆👇",
            "description": "Метод двух указателей"
        },
        "bitmasks": {
            "name": "Битовые маски",
            "emoji": "🔢",
            "description": "Битовые операции, перебор масок"
        },
        "geometry": {
            "name": "Геометрия",
            "emoji": "📐",
            "description": "Вычислительная геометрия"
        },
        "combinatorics": {
            "name": "Комбинаторика",
            "emoji": "🎲",
            "description": "Комбинаторные задачи, вероятности"
        },
        "number theory": {
            "name": "Теория чисел",
            "emoji": "🔢",
            "description": "Делители, простые числа, НОД"
        },
        "interactive": {
            "name": "Интерактивные задачи",
            "emoji": "💬",
            "description": "Задачи с интерактивным протоколом"
        },
        "constructive": {
            "name": "Конструктивные задачи",
            "emoji": "🏗️",
            "description": "Построение примеров и контрпримеров"
        }
    }

    @staticmethod
    def get_difficulty_info(difficulty: int) -> Dict[str, Any]:
        """Получить информацию о сложности"""
        return ContestConfig.DIFFICULTY_LEVELS.get(
            difficulty,
            ContestConfig.DIFFICULTY_LEVELS[3]  # По умолчанию средний уровень
        )

    @staticmethod
    def calculate_contest_time(difficulty: int, problem_count: int) -> int:
        """Рассчитать рекомендуемое время контеста в минутах"""
        # Базовое время в зависимости от количества задач
        base_time_per_problem = {
            2: 45,  # 45 минут на 2 задачи
            3: 60,  # 1 час на 3 задачи
            4: 90,  # 1.5 часа на 4 задачи
            5: 120,  # 2 часа на 5 задач
            6: 150,  # 2.5 часа на 6 задач
            7: 180,  # 3 часа на 7 задач
            8: 210,  # 3.5 часа на 8 задач
            9: 240,  # 4 часа на 9 задач
            10: 270,  # 4.5 часа на 10 задач
        }

        # Время по умолчанию
        base_time = base_time_per_problem.get(
            problem_count,
            problem_count * 30  # 30 минут на задачу по умолчанию
        )

        # Множитель сложности
        difficulty_multipliers = {
            1: 0.7,  # Новичок - меньше времени
            2: 0.9,  # Легкий
            3: 1.0,  # Средний (базовый)
            4: 1.3,  # Сложный
            5: 1.6,  # Эксперт
            6: 2.0,  # Легендарный
        }

        multiplier = difficulty_multipliers.get(difficulty, 1.0)
        return int(base_time * multiplier)

    @staticmethod
    def format_time(minutes: int) -> str:
        """Красиво отформатировать время"""
        if minutes < 60:
            return f"{minutes} минут"

        hours = minutes // 60
        mins = minutes % 60

        if mins == 0:
            return f"{hours} час{'ов' if hours % 10 != 1 else ''}"
        elif hours == 1:
            return f"{hours} час {mins} минут"
        else:
            return f"{hours} час{'а' if 2 <= hours % 10 <= 4 else 'ов'} {mins} минут"


# ==================== НАСТРОЙКИ ПЕРЕВОДА ====================

class TranslationConfig:
    """Конфигурация переводчика задач"""

    # Поддерживаемые языки
    SUPPORTED_LANGUAGES = {
        "ru": {
            "name": "Русский",
            "emoji": "🇷🇺",
            "direction": "ltr"
        },
        "en": {
            "name": "Английский",
            "emoji": "🇬🇧",
            "direction": "ltr"
        },
        "es": {
            "name": "Испанский",
            "emoji": "🇪🇸",
            "direction": "ltr"
        },
        "fr": {
            "name": "Французский",
            "emoji": "🇫🇷",
            "direction": "ltr"
        },
        "de": {
            "name": "Немецкий",
            "emoji": "🇩🇪",
            "direction": "ltr"
        },
        "zh": {
            "name": "Китайский",
            "emoji": "🇨🇳",
            "direction": "ltr"
        },
        "ja": {
            "name": "Японский",
            "emoji": "🇯🇵",
            "direction": "ltr"
        },
        "ko": {
            "name": "Корейский",
            "emoji": "🇰🇷",
            "direction": "ltr"
        },
        "ar": {
            "name": "Арабский",
            "emoji": "🇸🇦",
            "direction": "rtl"
        },
        "hi": {
            "name": "Хинди",
            "emoji": "🇮🇳",
            "direction": "ltr"
        }
    }

    DEFAULT_LANGUAGE = "ru"

    # Регулярные выражения для парсинга URL Codeforces
    URL_PATTERNS = [
        r'contest/(\d+)/problem/([A-Za-z0-9]+)',  # Обычные контесты
        r'problemset/problem/(\d+)/([A-Za-z0-9]+)',  # Проблемсет
        r'problem/(\d+)/([A-Za-z0-9]+)',  # Сокращенный URL
        r'gym/(\d+)/problem/([A-Za-z0-9]+)',  # Тренировки (gym)
        r'group/([^/]+)/contest/(\d+)/problem/([A-Za-z0-9]+)',  # Групповые контесты
    ]

    # Заголовки для HTTP запросов
    HTTP_HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9,ru;q=0.8',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Cache-Control': 'max-age=0',
        'DNT': '1',
    }

    # Таймауты
    REQUEST_TIMEOUT = 25
    MAX_RETRIES = 3
    RETRY_DELAY = 3

    # Настройки парсинга
    MAX_CONTENT_LENGTH = 50000  # Максимальная длина контента для парсинга
    MIN_CONTENT_LENGTH = 100  # Минимальная длина контента


# ==================== КЛЮЧЕВЫЕ СЛОВА ДЛЯ АНАЛИЗА ЗАПРОСОВ ====================

class KeywordsConfig:
    """Конфигурация ключевых слов для анализа запросов"""

    # Ключевые слова для запросов контестов
    CONTEST_KEYWORDS = [
        "задач", "задача", "контест", "соревнование", "турнир",
        "подбор", "подобрать", "набор", "комплект", "подготовк",
        "тренировк", "практик", "упражнен", "решен", "разбор",
        "алгоритм", "программир", "код", "олимпиад", "соревнова",
        "codeforces", "cf", "div", "division", "раунд", "round",
        "problem", "contest", "code", "algorithm", "training",
        "practice", "solve", "solution", "exercise", "challenge",
        "difficulty", "topic", "theme", "category", "rating",
        "hard", "easy", "medium", "difficult", "complexity",
        "уровень", "сложность", "тема", "категория", "рейтинг",
        "сложн", "легк", "средн", "хард", "изи", "медиум",
    ]

    # Ключевые слова для запросов перевода
    TRANSLATION_KEYWORDS = [
        "перевед", "перевод", "перевести", "переведи",
        "на русск", "по-русски", "русск", "английск",
        "язык", "language", "translate", "translation",
        "english", "russian", "spanish", "french", "german",
        "китайск", "японск", "корейск", "арабск", "испанск",
        "французск", "немецк", "хинди", "португальск",
        "italian", "chinese", "japanese", "korean", "arabic",
        "hindi", "portuguese", "italiano", "español", "français",
        "deutsch", "中文", "日本語", "한국어", "العربية",
    ]

    # Неавторизованные запросы (помощь в решении)
    UNAUTHORIZED_KEYWORDS = [
        "создай код", "напиши программу", "реши задачу",
        "напиши решение", "сделай за меня", "взломай",
        "обмани", "мошеннич", "читер", "читери", "списыван",
        "ответ", "ответы", "готовое", "готовый", "полное",
        "целое", "весь код", "весь решени", "полный код",
        "закончен", "завершен", "выполнен", "сделан",
        "cheat", "hack", "bypass", "exploit", "solution",
        "solve for me", "do my homework", "complete assignment",
        "bypass security", "give answer", "provide solution",
        "full code", "complete code", "entire solution",
        "write code", "write program", "solve problem",
        "do it for me", "help me cheat", "help me solve",
    ]

    # Запросы помощи
    HELP_KEYWORDS = [
        "помощь", "help", "помоги", "подскажи", "подсказка",
        "как пользоваться", "что ты умеешь", "возможности",
        "инструкция", "руководство", "гайд", "туториал",
        "справка", "документация", "объясни", "расскажи",
        "меню", "start", "начать", "старт", "команды",
        "что делать", "как работать", "как начать",
        "help me", "how to use", "what can you do",
        "capabilities", "features", "instructions",
        "guide", "tutorial", "documentation", "manual",
        "getting started", "quick start", "beginner",
        "новичок", "начинающ", "основы", "база",
        "введение", "вводная", "ознакомление",
    ]

    # Слова подтверждения
    CONFIRMATION_KEYWORDS = [
        "да", "yes", "ок", "хорошо", "продолжить",
        "конечно", "ага", "угу", "согласен", "подтверждаю",
        "подтвердить", "ok", "go", "continue", "принять",
        "accept", "давай", "начинай", "старт", "start",
        "yes please", "да пожалуйста", "хочу", "готов",
        "сделай", "выполни", "запускай", "вперед",
        "let's go", "proceed", "approve", "confirm",
        "согласн", "подтвержд", "приним", "готов",
        "сделаем", "начнем", "поехали", "вперед",
    ]

    # Слова отказа
    REJECTION_KEYWORDS = [
        "нет", "no", "отмена", "отменить", "стоп", "stop",
        "cancel", "не надо", "не нужно", "не хочу",
        "выход", "exit", "quit", "abort", "nevermind",
        "забудь", "прекрати", "останови", "перестань",
        "не стоит", "не надо", "отказ", "отказываюсь",
        "no thanks", "not now", "later", "maybe later",
        "I'll pass", "decline", "reject", "negative",
        "не согласен", "не принимаю", "не готов",
        "не сейчас", "потом", "позже", "в другой раз",
    ]

    # Тематические ключевые слова для извлечения тем
    TOPIC_KEYWORDS = {
        "dp": ["динамик", "динамическое", "dp", "dynamic programming"],
        "math": ["матем", "математик", "math", "mathematics"],
        "greedy": ["жадн", "greedy", "жадный", "жадные"],
        "graphs": ["граф", "graph", "графы", "графов", "ребер", "вершин"],
        "trees": ["дерев", "tree", "дерево", "деревья", "lca", "дерева"],
        "strings": ["строк", "string", "строки", "подстрока", "палиндром"],
        "binary search": ["бинар", "binary", "поиск", "search", "бинпоиск"],
        "data structures": ["структур", "data structure", "структуры", "стек", "очередь"],
        "implementation": ["реализац", "implementation", "реализация", "код"],
        "geometry": ["геометр", "geometry", "точка", "прямая", "окружность"],
        "combinatorics": ["комбинатор", "combinatorics", "сочетания", "перестановки"],
        "number theory": ["теория чисел", "number theory", "простые", "делители"],
        "interactive": ["интерактив", "interactive", "запрос", "ответ"],
        "bitmasks": ["битов", "bitmask", "маска", "битовые", "битмаска"],
        "sortings": ["сортиров", "sorting", "сортировка", "отсортировать"],
        "two pointers": ["два указателя", "two pointers", "указатели"],
        "brute force": ["перебор", "brute force", "полный перебор"],
    }


# ==================== СООБЩЕНИЯ И СТАТУСЫ ====================

class MessagesConfig:
    """Конфигурация сообщений и статусов"""

    # Коды статусов
    STATUS_CODES = {
        "SUCCESS": 200,
        "CREATED": 201,
        "ACCEPTED": 202,
        "BAD_REQUEST": 400,
        "UNAUTHORIZED": 401,
        "FORBIDDEN": 403,
        "NOT_FOUND": 404,
        "METHOD_NOT_ALLOWED": 405,
        "CONFLICT": 409,
        "TOO_MANY_REQUESTS": 429,
        "INTERNAL_ERROR": 500,
        "SERVICE_UNAVAILABLE": 503,
        "GATEWAY_TIMEOUT": 504,
        "USER_ABORTED": 499,
        "VALIDATION_ERROR": 422,
        "MODEL_ERROR": 520,
        "NETWORK_ERROR": 521,
        "PARSING_ERROR": 522,
    }

    # Сообщения для пользователя
    USER_MESSAGES = {
        "WELCOME": "🤖 Привет! Я твой AI-тренер по спортивному программированию!",

        "HELP_TITLE": "✨ Что я умею:",
        "HELP_CONTEST": "🎯 **Генерация контестов**\n• Персональные подборки задач\n• Разные уровни сложности\n• Фокус на конкретные темы\n• Рекомендации по решению",
        "HELP_TRANSLATION": "🌍 **Перевод задач**\n• Перевод с английского на русский\n• Сохранение формул и терминов\n• Поддержка разных языков\n• Точный технический перевод",
        "HELP_ADVICE": "💡 **Советы и анализ**\n• Рекомендации по подготовке\n• Анализ прогресса\n• Планы тренировок\n• Разбор ошибок",

        "GENERATE_BUTTON": "🎯 Контест сгенерирован успешно!",
        "TRANSLATION_SUCCESS": "✅ Перевод задачи выполнен!",
        "HELP_SUCCESS": "ℹ️ Вот что я умею:",

        "GOOD_LUCK": "💪 Удачи в решении! Помни, что каждая задача делает тебя лучше!",
        "ABORTED": "✅ Операция отменена. Всегда рад помочь с другим запросом!",

        "UNAUTHORIZED_WARNING": "⚠️ **Внимание: я создан для помощи в обучении**\n\nЯ НЕ МОГУ:\n• Решать задачи за тебя\n• Предоставлять готовые решения\n• Помогать в мошенничестве\n\nЯ МОГУ:\n• Генерировать тренировочные контесты\n• Переводить условия задач\n• Давать советы по подготовке\n• Объяснять алгоритмы и концепции",

        "CONFIRM_CONTINUE": "Если ты хотел сгенерировать контест или перевести задачу, просто ответь 'да'.",

        "INVALID_INPUT": "❌ **Пожалуйста, уточни запрос**\n\nПримеры правильных запросов:\n• 'Сгенерируй контест из 5 задач по графам средней сложности'\n• 'Переведи задачу https://codeforces.com/contest/4/problem/A'\n• 'Помоги подготовиться к Div2, я решаю задачи уровня 1200'\n• 'Нужен контест для начинающих на 60 минут'",

        "TRANSLATION_ERROR": "❌ **Не удалось перевести задачу**\n\nВозможные причины:\n• Неправильная ссылка на Codeforces\n• Задача удалена или недоступна\n• Проблемы с интернет-соединением\n• Ошибка парсинга страницы\n\nПопробуй:\n1. Проверить правильность ссылки\n2. Убедиться, что задача существует\n3. Попробовать позже",

        "CONTEST_ERROR": "❌ **Не удалось сгенерировать контест**\n\nПопробуй:\n• Изменить параметры сложности\n• Выбрать другую тему\n• Уменьшить количество задач\n• Попробовать позже",

        "NO_INTERNET": "🌐 **Нет соединения с интернетом**\nПроверь подключение и попробуй снова.",

        "RATE_LIMIT": "⏳ **Слишком много запросов**\nПожалуйста, подожди немного перед следующим запросом.",

        "API_ERROR": "🔧 **Ошибка API**\nПопробуй позже или свяжись с поддержкой.",

        "LOADING": "⏳ Обрабатываю запрос... Это может занять несколько секунд.",

        "PROCESSING": "⚙️ Анализирую твой запрос и подбираю оптимальные задачи...",

        "READY": "✅ Система готова к работе! Напиши, что тебе нужно.",
    }

    # Ободряющие сообщения
    ENCOURAGEMENTS = [
        "🔥 **Каждая решенная задача делает тебя сильнее!** Не останавливайся на достигнутом!",
        "🚀 **Ты можешь больше, чем думаешь!** Верь в свои силы и продолжай тренироваться!",
        "🌟 **Ошибки — это шаги к мастерству!** Каждая ошибка учит чему-то новому!",
        "📈 **Сегодняшняя тренировка — завтрашний успех!** Регулярность — ключ к прогрессу!",
        "💡 **Не сдавайся!** Самые сложные задачи дают самый большой рост!",
        "⏱️ **Каждая минута кодинга приближает тебя к цели!** Не теряй время зря!",
        "🔥 **Ты на правильном пути!** Продолжай в том же духе, и результат не заставит себя ждать!",
        "🌈 **Верь в себя, как я верю в тебя!** Ты справишься с любыми задачами!",
        "🎯 **Маленькие шаги каждый день приводят к большим результатам!** Главное — не останавливаться!",
        "🏆 **Твой прогресс впечатляет!** Не останавливайся, продолжай двигаться вперед!",
        "💪 **Ты становишься лучше с каждой решенной задачей!** Это заметно!",
        "🚀 **Не бойся сложных задач!** Именно они делают тебя опытнее и увереннее!",
        "🌟 **Каждая ошибка — это возможность научиться чему-то новому!** Анализируй и улучшайся!",
        "🔥 **Твоя настойчивость обязательно приведет к успеху!** Продолжай в том же духе!",
        "🎯 **Помни: даже самые крутые программисты начинали с простых задач!** У тебя все получится!",
        "💪 **Ты уже прошел большой путь!** Осталось совсем немного до новых вершин!",
        "🚀 **Сложные задачи — это вызов, который делает тебя сильнее!** Принимай его!",
        "🌟 **Каждая решенная задача — это новая суперспособность в твоем арсенале!** Собирай их все!",
        "🔥 **Твоя упорство впечатляет!** Продолжай в том же духе, и скоро ты будешь решать любые задачи!",
        "🎯 **Не сравнивай себя с другими!** Сравнивай себя сегодняшнего с собой вчерашним!",
    ]

    @staticmethod
    def get_random_encouragement() -> str:
        """Получить случайное ободряющее сообщение"""
        return random.choice(MessagesConfig.ENCOURAGEMENTS)

    @staticmethod
    def get_status_message(status_code: int) -> str:
        """Получить сообщение по коду статуса"""
        status_mapping = {
            200: "Успешно",
            201: "Создано",
            400: "Неверный запрос",
            403: "Доступ запрещен",
            404: "Не найдено",
            429: "Слишком много запросов",
            500: "Внутренняя ошибка",
            503: "Сервис недоступен",
            499: "Пользователь отменил",
        }
        return status_mapping.get(status_code, "Неизвестный статус")


# ==================== ПРОМПТЫ ДЛЯ ИСКУССТВЕННОГО ИНТЕЛЛЕКТА ====================

class PromptsConfig:
    """Конфигурация промптов для LLM"""

    # Промпт для генерации контестов
    CONTEST_GENERATION_PROMPT = """
Ты — опытный тренер по спортивному программированию с 10-летним стажем.
Твоя задача — создать персональный тренировочный контест на Codeforces.

ПАРАМЕТРЫ КОНТЕСТА:
{params_summary}

КРИТИЧЕСКИ ВАЖНЫЕ ПРАВИЛА:
1. ВСЕГДА отвечай ТОЛЬКО в формате JSON
2. Используй ТОЛЬКО реальные существующие задачи с Codeforces
3. Всегда указывай корректные прямые ссылки на задачи
4. Указывай актуальный рейтинг задач (от 800 до 3500)
5. Подбирай задачи разного уровня сложности в рамках указанного диапазона
6. Соблюдай логический порядок решения: от простого к сложному
7. Учитывай указанную тему контеста

ФОРМАТ ОТВЕТА (JSON):
{{
  "title": "Креативное и мотивирующее название контеста",
  "description": "Подробное описание контеста на 2-3 предложения. Объясни, какие навыки развивает этот контест.",
  "difficulty": "Общий уровень сложности контеста ({difficulty_label})",
  "estimated_time": "Рекомендуемое время на решение в минутах",
  "total_problems": {problem_count},
  "problems": [
    {{
      "order": 1,
      "title": "Полное официальное название задачи с Codeforces",
      "url": "https://codeforces.com/problemset/problem/XX/Y (полная ссылка)",
      "rating": 800,
      "topics": ["основная_тема", "дополнительная_тема"],
      "time_estimate": "10-15 минут",
      "difficulty_for_user": "Очень легко",
      "hint": "Конкретная полезная подсказка для начала решения",
      "why_important": "Объяснение, почему эта задача важна для развития навыков",
      "prerequisites": "Какие знания нужны для решения"
    }}
  ],
  "recommended_order": "Подробное объяснение рекомендуемого порядка решения задач",
  "strategy_advice": "Советы по стратегии решения этого конкретного контеста",
  "common_pitfalls": "Частые ошибки, которых стоит избегать",
  "tips": [
    "Практический совет 1",
    "Практический совет 2", 
    "Практический совет 3"
  ],
  "success_criteria": "Что считать успешным прохождением этого контеста",
  "next_steps": "Что делать после решения этого контеста"
}}

ТЕХНИЧЕСКИЕ ТРЕБОВАНИЯ:
• Количество задач: {problem_count}
• Основная тема: {topic_name}
• Общее время: {contest_time} минут
• Уровень сложности: {difficulty_label}
• Диапазон рейтинга: {min_rating}-{max_rating}

Сделай контест полезным, мотивирующим, реалистичным и соответствующим уровню пользователя!
"""

    # Промпт для перевода задач
    TRANSLATION_PROMPT = """
Ты — профессиональный переводчик технических текстов с экспертизой в спортивном программировании.
Твоя задача — перевести условие задачи с Codeforces максимально точно и технически корректно.

ЯЗЫК ПЕРЕВОДА: {target_language}
ОРИГИНАЛЬНЫЙ URL: {original_url}

ТЕКСТ ЗАДАЧИ ДЛЯ ПЕРЕВОДА:
{problem_text}

КРИТИЧЕСКИ ВАЖНЫЕ ПРАВИЛА ПЕРЕВОДА:
1. Сохрани ВСЕ математические формулы, нотации, обозначения и символы БЕЗ ИЗМЕНЕНИЙ
2. Технические термины переводи максимально точно, используя общепринятые в русскоязычном сообществе переводы
3. Сохрани оригинальное форматирование: таблицы, примеры, списки, отступы
4. Имена переменных, функций, классов, констант оставляй НА ЛАТИНИЦЕ без изменений
5. Название задачи должно звучать естественно на целевом языке, но быть точным
6. Сохрани полную структуру задачи: Условие → Входные данные → Выходные данные → Примеры → Примечания → Ограничения
7. Все числовые значения, единицы измерения, специальные символы оставляй без изменений
8. Если есть формулы в LaTeX — не меняй их вообще, оставляй как есть
9. Технические термины, которые не имеют устоявшегося перевода, оставляй на английском
10. Сохрани все технические детали и точные формулировки

ФОРМАТ ОТВЕТА (строго JSON):
{{
  "original_title": "Оригинальное название задачи на английском",
  "translated_title": "Переведенное название задачи на {target_language}",
  "language": "{target_language}",
  "difficulty": "Уровень сложности задачи (если известен)",
  "topics": ["Основные темы и алгоритмы, используемые в задаче"],
  "translation": {{
    "statement": "Полный переведенный текст условия задачи",
    "input_specification": "Детальное описание формата входных данных",
    "output_specification": "Детальное описание формата выходных данных", 
    "examples": [
      {{
        "input": "Точные входные данные примера",
        "output": "Точные выходные данные примера", 
        "explanation": "Пояснение к примеру (если есть в оригинале)"
      }}
    ],
    "notes": "Все примечания и дополнительные условия",
    "constraints": "Все ограничения и условия"
  }},
  "metadata": {{
    "original_url": "{original_url}",
    "translation_date": "{current_date}",
    "character_count": "Количество символов в переводе",
    "preserved_formulas": true,
    "technical_terms_consistent": true,
    "formatting_preserved": true
  }},
  "translation_notes": "Замечания переводчика о сложностях перевода, спорных моментах или особенностях",
  "key_terms": {{
    "original": ["ключевой_термин_1", "ключевой_термин_2"],
    "translated": ["переведенный_термин_1", "переведенный_термин_2"]
  }}
}}

Будь максимально точным, технически корректным, сохраняй все детали и следуй лучшим практикам технического перевода!
"""

    # Промпт для помощи
    HELP_PROMPT = """
Ты — дружелюбный, knowledgeable и мотивирующий AI-помощник для программистов, специализирующийся на Codeforces и спортивном программировании.
Твоя задача — помочь пользователю понять твои возможности и начать эффективно тренироваться.

ЗАПРОС ПОЛЬЗОВАТЕЛЯ:
{user_query}

ИНФОРМАЦИЯ О ТЕБЕ:
Ты — AI-тренер по спортивному программированию, созданный чтобы помогать программистам готовиться к Codeforces и другим платформам.
Твоя миссия — сделать тренировки эффективными, мотивирующими и персонализированными.

ТВОИ ОСНОВНЫЕ ВОЗМОЖНОСТИ:

🎯 **ГЕНЕРАЦИЯ ПЕРСОНАЛЬНЫХ КОНТЕСТОВ**
• Подбор задач по конкретным темам и сложности
• Расчет оптимального времени на решение
• Рекомендации по порядку решения задач
• Советы по стратегии подготовки
• Учет текущего уровня пользователя

🌍 **ПЕРЕВОД ЗАДАЧ**
• Профессиональный перевод условий с английского на русский и другие языки
• Сохранение всех математических формул и технических терминов
• Точный перевод с учетом контекста программирования
• Поддержка различных языков перевода

📊 **АНАЛИЗ И РЕКОМЕНДАЦИИ**  
• Оценка текущего уровня подготовки
• Рекомендации по темам для изучения
• Персональные планы подготовки к соревнованиям
• Разбор типичных ошибок и проблем
• Отслеживание прогресса

💡 **ОБУЧЕНИЕ И ОБЪЯСНЕНИЯ**
• Объяснение алгоритмов и структур данных
• Разбор решений сложных задач
• Советы по оптимизации кода и производительности
• Подготовка к техническим интервью
• Обучение через практику и примеры

🔥 **МОТИВАЦИЯ И ПОДДЕРЖКА**
• Ободряющие сообщения и поддержка
• Помощь в преодолении трудностей
• Советы по поддержанию регулярности тренировок
• Помощь в постановке целей
• Отслеживание прогресса и достижений

ФОРМАТ ОТВЕТА (JSON):
{{
  "welcome_message": "Дружелюбное приветственное сообщение, обращенное к пользователю",
  "capabilities": [
    "🎯 Генерация персонализированных контестов",
    "🌍 Профессиональный перевод задач",
    "📊 Анализ уровня и рекомендации",
    "💡 Обучение и объяснения",
    "🔥 Мотивация и поддержка"
  ],
  "how_to_use": "Краткая и понятная инструкция по началу работы. Объясни, как лучше всего использовать твои возможности.",
  "examples": [
    "Пример 1: 'Сгенерируй контест из 5 задач средней сложности по динамическому программированию'",
    "Пример 2: 'Переведи задачу https://codeforces.com/contest/4/problem/A на русский язык'",
    "Пример 3: 'Помоги подготовиться к Div2, я сейчас решаю задачи уровня 1200-1300'",
    "Пример 4: 'Нужен контест для начинающих на 60 минут, чтобы потренировать базовые алгоритмы'",
    "Пример 5: 'Подскажи, какие темы мне стоит изучить, если я хочу улучшить свой рейтинг с 1400 до 1600'"
  ],
  "quick_start": "Самый быстрый способ начать: просто опиши, что тебе нужно, и я помогу!",
  "motivation": "Вдохновляющая и мотивирующая фраза, которая подбодрит пользователя начать тренироваться",
  "common_use_cases": [
    "Подготовка к конкретному раунду Codeforces",
    "Изучение новой темы или алгоритма",
    "Тренировка решения задач на время",
    "Подготовка к собеседованию в IT-компанию",
    "Улучшение навыков решения алгоритмических задач"
  ]
}}

Будь дружелюбным, полезным, мотивирующим и покажи, что ты действительно хочешь помочь пользователю стать лучше!
"""

    @staticmethod
    def format_contest_prompt(params_summary: str, problem_count: int,
                              contest_time: int, difficulty_label: str,
                              topic_name: str, min_rating: int, max_rating: int) -> str:
        """Форматировать промпт для генерации контеста"""
        return PromptsConfig.CONTEST_GENERATION_PROMPT.format(
            params_summary=params_summary,
            problem_count=problem_count,
            contest_time=contest_time,
            difficulty_label=difficulty_label,
            topic_name=topic_name,
            min_rating=min_rating,
            max_rating=max_rating
        )

    @staticmethod
    def format_translation_prompt(problem_text: str, target_language: str,
                                  original_url: str) -> str:
        """Форматировать промпт для перевода"""
        current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return PromptsConfig.TRANSLATION_PROMPT.format(
            problem_text=problem_text,
            target_language=target_language,
            original_url=original_url,
            current_date=current_date
        )

    @staticmethod
    def format_help_prompt(user_query: str) -> str:
        """Форматировать промпт для помощи"""
        return PromptsConfig.HELP_PROMPT.format(user_query=user_query)


# ==================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ====================

def create_input_template(template_type: str = "contest") -> Dict[str, Any]:
    """
    Создать шаблон входных данных для разных типов запросов

    Args:
        template_type: Тип шаблона ("contest", "translation", "help", "analysis")

    Returns:
        Словарь с шаблоном входных данных
    """
    templates = {
        "contest": {
            "content": "Сгенерируй контест из 5 задач средней сложности на разные темы для подготовки к Div2",
            "difficulty": 3,
            "bad_themes": False,
            "main_theme": None,
            "problem_count": ContestConfig.DEFAULT_PROBLEM_COUNT,
            "time_minutes": None,
            "is_confirmation": False,
            "request_type": "contest",
            "user_level": 1300,
            "focus_on_weak_topics": False,
            "include_solution_hints": True,
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "template_version": "1.0"
            }
        },

        "translation": {
            "content": "https://codeforces.com/contest/4/problem/A",
            "target_language": "ru",
            "is_confirmation": False,
            "request_type": "translation",
            "include_explanation": True,
            "preserve_formatting": True,
            "simplify_language": False,
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "template_version": "1.0"
            }
        },

        "help": {
            "content": "помощь",
            "is_confirmation": False,
            "request_type": "help",
            "detailed_help": True,
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "template_version": "1.0"
            }
        },

        "analysis": {
            "content": "Проанализируй мой прогресс, я решаю задачи уровня 1200-1400",
            "is_confirmation": False,
            "request_type": "analysis",
            "analysis_type": "progress",
            "time_period": "last_month",
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "template_version": "1.0"
            }
        }
    }

    return templates.get(template_type, templates["contest"])


def validate_input_data(data: Dict[str, Any]) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Валидация входных данных

    Args:
        data: Входные данные для валидации

    Returns:
        Tuple[success, error_message, validated_data]
    """
    if not data:
        return False, "Пустые входные данные", {}

    # Копируем данные для модификации
    validated_data = data.copy()

    # Проверяем обязательное поле content
    if "content" not in data:
        return False, "Отсутствует обязательное поле 'content'", {}

    content = data.get("content", "").strip()
    if not content:
        return False, "Поле 'content' не может быть пустым", {}

    # Проверка на неавторизованный контент
    content_lower = content.lower()
    for keyword in KeywordsConfig.UNAUTHORIZED_KEYWORDS:
        if keyword in content_lower:
            return False, MessagesConfig.USER_MESSAGES["UNAUTHORIZED_WARNING"], {}

    # Определяем тип запроса
    request_type = data.get("request_type", "unknown")
    if request_type == "unknown":
        # Автоматически определяем тип
        if any(keyword in content_lower for keyword in KeywordsConfig.CONTEST_KEYWORDS):
            request_type = "contest"
        elif any(keyword in content_lower for keyword in KeywordsConfig.TRANSLATION_KEYWORDS):
            request_type = "translation"
        elif any(keyword in content_lower for keyword in KeywordsConfig.HELP_KEYWORDS):
            request_type = "help"
        elif content_lower.startswith("http") and "codeforces.com" in content_lower:
            request_type = "translation"
        else:
            request_type = "contest"  # По умолчанию

    validated_data["request_type"] = request_type

    # Валидация для контестов
    if request_type == "contest":
        # Проверка сложности
        difficulty = data.get("difficulty", 3)
        if not isinstance(difficulty, int):
            try:
                difficulty = int(difficulty)
            except:
                difficulty = 3

        if difficulty < 1 or difficulty > 6:
            difficulty = 3

        validated_data["difficulty"] = difficulty

        # Проверка количества задач
        problem_count = data.get("problem_count", ContestConfig.DEFAULT_PROBLEM_COUNT)
        if not isinstance(problem_count, int):
            try:
                problem_count = int(problem_count)
            except:
                problem_count = ContestConfig.DEFAULT_PROBLEM_COUNT

        problem_count = max(ContestConfig.MIN_PROBLEMS,
                            min(problem_count, ContestConfig.MAX_PROBLEMS))
        validated_data["problem_count"] = problem_count

        # Проверка времени
        if "time_minutes" in data and data["time_minutes"] is not None:
            time_minutes = data["time_minutes"]
            if not isinstance(time_minutes, int):
                try:
                    time_minutes = int(time_minutes)
                except:
                    time_minutes = None

            if time_minutes and (time_minutes < 15 or time_minutes > 480):
                time_minutes = None

            validated_data["time_minutes"] = time_minutes

    # Валидация для перевода
    elif request_type == "translation":
        target_language = data.get("target_language", TranslationConfig.DEFAULT_LANGUAGE)
        if target_language not in TranslationConfig.SUPPORTED_LANGUAGES:
            target_language = TranslationConfig.DEFAULT_LANGUAGE
        validated_data["target_language"] = target_language

        # Проверка URL
        if content.startswith("http") and "codeforces.com" in content:
            validated_data["is_valid_url"] = True
        else:
            validated_data["is_valid_url"] = False

    # Добавляем метаданные
    if "metadata" not in validated_data:
        validated_data["metadata"] = {}

    validated_data["metadata"]["validated_at"] = datetime.now().isoformat()
    validated_data["metadata"]["validation_status"] = "success"

    return True, "Валидация пройдена успешно", validated_data


def save_input_template_to_file(filename: str = "input_template.json",
                                template_type: str = "contest"):
    """
    Сохранить шаблон входных данных в файл

    Args:
        filename: Имя файла для сохранения
        template_type: Тип шаблона
    """
    template = create_input_template(template_type)

    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(template, f, indent=2, ensure_ascii=False)
        print(f"✅ Шаблон сохранен в файл: {filename}")
        print(f"📝 Тип шаблона: {template_type}")
    except Exception as e:
        print(f"❌ Ошибка сохранения шаблона: {e}")


def print_config_summary():
    """Вывести сводную информацию о конфигурации"""
    print("\n" + "=" * 60)
    print("📊 СВОДКА КОНФИГУРАЦИИ")
    print("=" * 60)

    print(f"🔑 API ключ: {'✅ Найден' if MISTRAL_API_KEY else '❌ Отсутствует'}")
    print(f"🤖 Модель: {APIConfig.MISTRAL_MODEL}")
    print(f"🎯 Уровней сложности: {len(ContestConfig.DIFFICULTY_LEVELS)}")
    print(f"📚 Тем для контестов: {len(ContestConfig.CF_TOPICS)}")
    print(f"🌍 Языков перевода: {len(TranslationConfig.SUPPORTED_LANGUAGES)}")
    print(f"💬 Сообщений поддержки: {len(MessagesConfig.ENCOURAGEMENTS)}")

    print("\n📁 Директории:")
    PathConfig.setup_directories()

    print("\n🚀 Система готова к работе!")


# ==================== ИНИЦИАЛИЗАЦИЯ И ЭКСПОРТ ====================

# Создаем алиасы для удобного импорта
MIN_PROBLEMS = ContestConfig.MIN_PROBLEMS
MAX_PROBLEMS = ContestConfig.MAX_PROBLEMS
DEFAULT_PROBLEM_COUNT = ContestConfig.DEFAULT_PROBLEM_COUNT
CF_TOPICS = ContestConfig.CF_TOPICS

get_difficulty_info = ContestConfig.get_difficulty_info
calculate_contest_time = ContestConfig.calculate_contest_time
format_time = ContestConfig.format_time

PROGRAMMING_KEYWORDS = KeywordsConfig.CONTEST_KEYWORDS
UNAUTHORIZED_KEYWORDS = KeywordsConfig.UNAUTHORIZED_KEYWORDS
HELP_KEYWORDS = KeywordsConfig.HELP_KEYWORDS
CONFIRMATION_KEYWORDS = KeywordsConfig.CONFIRMATION_KEYWORDS

STATUS = MessagesConfig.STATUS_CODES
MESSAGES = MessagesConfig.USER_MESSAGES
get_random_encouragement = MessagesConfig.get_random_encouragement

CONTEST_GENERATION_PROMPT = PromptsConfig.CONTEST_GENERATION_PROMPT
TRANSLATION_PROMPT = PromptsConfig.TRANSLATION_PROMPT
HELP_PROMPT = PromptsConfig.HELP_PROMPT

# Автоматическая инициализация при импорте
if __name__ != "__main__":
    print_config_summary()
else:
    # Если запускаем как основной скрипт
    print("=" * 60)
    print("🔧 ЗАПУСК КОНФИГУРАЦИИ CODEFORCES AGENT")
    print("=" * 60)

    print_config_summary()

    print("\n📋 ДОСТУПНЫЕ ШАБЛОНЫ ВХОДНЫХ ДАННЫХ:")
    for template_type in ["contest", "translation", "help", "analysis"]:
        template = create_input_template(template_type)
        content_preview = template["content"][:80] + "..." if len(template["content"]) > 80 else template["content"]
        print(f"  • {template_type.upper()}: {content_preview}")

    print("\n💡 КОМАНДЫ ДЛЯ ТЕСТИРОВАНИЯ:")
    print("  1. Создать шаблон для контеста: save_input_template_to_file('test_input.json', 'contest')")
    print("  2. Проверить валидацию: validate_input_data(create_input_template('contest'))")
    print("  3. Получить случайную мотивацию: get_random_encouragement()")

    print("\n" + "=" * 60)
    print("✅ КОНФИГУРАЦИЯ ЗАГРУЖЕНА УСПЕШНО!")
    print("=" * 60)